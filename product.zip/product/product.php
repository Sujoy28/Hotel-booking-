<?php
include("../connection.php");
var_dump($_SESSION['admin']);
?>