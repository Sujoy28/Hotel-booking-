<script>
    window.location.href='index.php';
</script>